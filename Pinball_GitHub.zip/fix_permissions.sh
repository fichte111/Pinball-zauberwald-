#!/bin/sh
# In AndroidIDE Terminal ausführen, falls gradlew nicht gefunden wird:
cd "$(dirname "$0")"
chmod +x gradlew
echo "gradlew ist jetzt ausführbar."
ls -la gradlew
