# Franz Fichtes Zauberwald Pinball

Offline Android Pinball-Spiel.

## APK bauen mit GitHub Actions

1. Dieses Repo auf GitHub hochladen
2. Unter **Actions** den Workflow **Build APK** starten (oder einfach pushen)
3. Nach dem grünen Haken: Artifact **pinball-apk** herunterladen
4. APK auf dem Handy installieren

## Features
- 3 Bälle, Multiball
- Highscore-Liste
- Targets, Bumper, Partikel
- Touch-Steuerung
