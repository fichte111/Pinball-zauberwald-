package de.franzfichte.zauberwaldpinball

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import org.json.JSONArray
import kotlin.math.*
import kotlin.random.Random

class PinballView(context: Context) : View(context) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val balls = mutableListOf<Ball>()
    private val particles = mutableListOf<Particle>()
    private var score = 0
    private var lives = 3
    private var playing = false
    private var showHighscores = false
    private var left = false
    private var right = false
    private var last = System.nanoTime()
    private var blink = 0f

    // Highscore list (top 5)
    private val prefs = context.getSharedPreferences("pinball", Context.MODE_PRIVATE)
    private val highscores = loadHighscores()

    // Targets: main 5 + 2 side bumpers
    private data class Target(
        var x: Float, var y: Float, var r: Float,
        var cooldown: Float = 0f,
        var points: Int = 100,
        var isBumper: Boolean = false
    )
    private val targets = mutableListOf<Target>()

    // Flipper geometry (better collision)
    private data class Flipper(
        var cx: Float, var cy: Float,   // pivot
        var length: Float,
        var angle: Float,               // rest angle in degrees
        var active: Boolean = false
    )
    private lateinit var leftFlipper: Flipper
    private lateinit var rightFlipper: Flipper

    data class Ball(var x: Float, var y: Float, var vx: Float, var vy: Float, var r: Float = 13f)
    data class Particle(
        var x: Float, var y: Float,
        var vx: Float, var vy: Float,
        var life: Float, var maxLife: Float,
        var color: Int, var size: Float
    )

    init {
        isFocusable = true
        isClickable = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        setupTable(w.toFloat(), h.toFloat())
    }

    private fun setupTable(w: Float, h: Float) {
        targets.clear()
        // 5 main targets in an arc
        val positions = listOf(
            0.18f to 0.28f, 0.32f to 0.22f, 0.50f to 0.18f,
            0.68f to 0.22f, 0.82f to 0.28f
        )
        positions.forEachIndexed { i, (px, py) ->
            targets.add(Target(w * px, h * py, 20f, points = 100 + i * 20))
        }
        // 2 side bumpers
        targets.add(Target(w * 0.18f, h * 0.48f, 28f, points = 50, isBumper = true))
        targets.add(Target(w * 0.82f, h * 0.48f, 28f, points = 50, isBumper = true))

        leftFlipper = Flipper(w * 0.32f, h * 0.84f, w * 0.22f, -25f)
        rightFlipper = Flipper(w * 0.68f, h * 0.84f, w * 0.22f, 25f)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val now = System.nanoTime()
        val dt = min(0.028f, (now - last) / 1_000_000_000f)
        last = now
        blink += dt

        drawTable(c, w, h)

        when {
            showHighscores -> drawHighscoreScreen(c, w, h)
            playing -> {
                updateParticles(dt)
                physics(w, h, dt)
                drawGame(c, w, h)
                postInvalidateOnAnimation()
            }
            else -> drawMenu(c, w, h)
        }
    }

    // ─── Drawing ───────────────────────────────────────────────

    private fun drawTable(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h,
            Color.rgb(22, 48, 24), Color.rgb(4, 8, 5), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // Forest
        p.color = Color.rgb(10, 26, 13)
        for (i in 0..12) {
            drawPine(c, i * w / 11f - 20f, h * 0.32f + (i % 4) * 40f, 65f + (i % 3) * 12f)
        }

        // Wooden frame
        p.color = Color.rgb(88, 50, 24)
        c.drawRoundRect(14f, 14f, w - 14f, h - 14f, 26f, 26f, p)
        p.color = Color.rgb(24, 12, 6)
        c.drawRoundRect(30f, 30f, w - 30f, h - 30f, 20f, 20f, p)
        p.color = Color.rgb(12, 36, 16)
        c.drawRoundRect(42f, 42f, w - 42f, h - 42f, 16f, 16f, p)

        // Top lights
        for (i in 0 until 14) {
            val a = if (sin(blink * 4.5f + i * 0.7f) > 0.15f) 255 else 70
            p.color = Color.argb(a, 200, 230, 70)
            c.drawCircle(55f + i * (w - 110f) / 13f, 55f, 4.5f, p)
        }
    }

    private fun drawPine(c: Canvas, x: Float, y: Float, size: Float) {
        p.color = Color.rgb(8, 22, 11)
        val path = Path()
        path.moveTo(x, y - size)
        path.lineTo(x - size * 0.5f, y + size * 0.5f)
        path.lineTo(x - size * 0.15f, y + size * 0.4f)
        path.lineTo(x - size * 0.7f, y + size)
        path.lineTo(x + size * 0.7f, y + size)
        path.lineTo(x + size * 0.15f, y + size * 0.4f)
        path.lineTo(x + size * 0.5f, y + size * 0.5f)
        path.close()
        c.drawPath(path, p)
    }

    private fun drawMenu(c: Canvas, w: Float, h: Float) {
        text(c, "FRANZ FICHTES", w / 2, h * 0.22f, 26f, Color.rgb(220, 190, 110), true)
        text(c, "ZAUBERWALD PINBALL", w / 2, h * 0.28f, 22f, Color.WHITE, true)
        text(c, "DÜSTERER WALD • HOLZ • LICHTER", w / 2, h * 0.35f, 12f, Color.LTGRAY, false)

        // START button
        p.color = Color.rgb(70, 110, 40)
        c.drawRoundRect(w * 0.22f, h * 0.42f, w * 0.78f, h * 0.52f, 16f, 16f, p)
        text(c, "START", w / 2, h * 0.485f, 24f, Color.WHITE, true)

        // Highscore button
        p.color = Color.rgb(50, 70, 90)
        c.drawRoundRect(w * 0.22f, h * 0.55f, w * 0.78f, h * 0.64f, 16f, 16f, p)
        text(c, "HIGHSCORES", w / 2, h * 0.61f, 18f, Color.WHITE, true)

        val best = highscores.firstOrNull() ?: 0
        text(c, "Best: $best", w / 2, h * 0.72f, 16f, Color.rgb(220, 200, 140), true)
        text(c, "3 Bälle  •  Multiball  •  Partikel", w / 2, h * 0.79f, 13f, Color.GRAY, false)
        text(c, "Links / Rechts tippen = Flipper", w / 2, h * 0.85f, 12f, Color.GRAY, false)
    }

    private fun drawHighscoreScreen(c: Canvas, w: Float, h: Float) {
        text(c, "HIGHSCORE-LISTE", w / 2, h * 0.18f, 24f, Color.rgb(220, 190, 110), true)

        if (highscores.isEmpty()) {
            text(c, "Noch keine Einträge", w / 2, h * 0.40f, 16f, Color.LTGRAY, false)
        } else {
            highscores.forEachIndexed { i, s ->
                val y = h * 0.28f + i * h * 0.08f
                val medal = when (i) {
                    0 -> Color.rgb(255, 215, 80)
                    1 -> Color.rgb(200, 200, 210)
                    2 -> Color.rgb(205, 140, 70)
                    else -> Color.rgb(160, 180, 150)
                }
                text(c, "${i + 1}.", w * 0.28f, y, 20f, medal, true)
                text(c, "$s", w * 0.55f, y, 20f, Color.WHITE, true)
            }
        }

        p.color = Color.rgb(70, 90, 50)
        c.drawRoundRect(w * 0.25f, h * 0.78f, w * 0.75f, h * 0.88f, 14f, 14f, p)
        text(c, "ZURÜCK", w / 2, h * 0.845f, 20f, Color.WHITE, true)
    }

    private fun drawGame(c: Canvas, w: Float, h: Float) {
        text(c, "SCORE  $score", 85f, 90f, 17f, Color.WHITE, true)
        text(c, "BÄLLE  $lives", w - 85f, 90f, 17f, Color.WHITE, true)

        // Targets
        for (t in targets) {
            if (t.isBumper) {
                p.color = if (t.cooldown > 0) Color.rgb(255, 180, 60) else Color.rgb(180, 100, 30)
                c.drawCircle(t.x, t.y, t.r, p)
                p.color = Color.rgb(40, 20, 5)
                c.drawCircle(t.x, t.y, t.r * 0.45f, p)
            } else {
                val lit = t.cooldown <= 0 && sin(blink * 5 + t.x * 0.01f) > 0
                p.color = if (lit) Color.rgb(230, 60, 45) else Color.rgb(80, 20, 18)
                c.drawCircle(t.x, t.y, t.r, p)
                p.color = Color.argb(100, 255, 200, 150)
                c.drawCircle(t.x - 4f, t.y - 4f, t.r * 0.3f, p)
            }
        }

        // Flippers
        drawFlipper(c, leftFlipper, left)
        drawFlipper(c, rightFlipper, right)

        // Balls
        for (b in balls) {
            p.color = Color.rgb(210, 210, 195)
            c.drawCircle(b.x, b.y, b.r, p)
            p.color = Color.argb(140, 255, 255, 240)
            c.drawCircle(b.x - 3.5f, b.y - 3.5f, b.r * 0.32f, p)
        }

        // Particles
        for (pt in particles) {
            val alpha = (pt.life / pt.maxLife * 255).toInt().coerceIn(0, 255)
            p.color = Color.argb(alpha, Color.red(pt.color), Color.green(pt.color), Color.blue(pt.color))
            c.drawCircle(pt.x, pt.y, pt.size * (pt.life / pt.maxLife), p)
        }
    }

    private fun drawFlipper(c: Canvas, f: Flipper, active: Boolean) {
        val angle = if (active) f.angle * 0.35f else f.angle   // swing up when active
        p.color = if (active) Color.rgb(220, 170, 70) else Color.rgb(120, 70, 30)
        c.save()
        c.rotate(angle, f.cx, f.cy)
        c.drawRoundRect(f.cx - f.length * 0.05f, f.cy - 11f, f.cx + f.length, f.cy + 11f, 10f, 10f, p)
        c.restore()
    }

    // ─── Physics ───────────────────────────────────────────────

    private fun physics(w: Float, h: Float, dt: Float) {
        val gravity = 780f

        for (t in targets) if (t.cooldown > 0) t.cooldown -= dt

        leftFlipper.active = left
        rightFlipper.active = right

        val iterator = balls.iterator()
        while (iterator.hasNext()) {
            val b = iterator.next()
            b.vy += gravity * dt
            b.x += b.vx * dt
            b.y += b.vy * dt

            // Walls (with soft bounce)
            wallBounce(b, 52f + b.r, true, 1f)          // left
            wallBounce(b, w - 52f - b.r, false, 1f)      // right
            if (b.y < 70f + b.r) {
                b.y = 70f + b.r
                b.vy = abs(b.vy) * 0.88f
            }

            // Targets / bumpers – proper circle collision + normal reflection
            for (t in targets) {
                if (t.cooldown > 0) continue
                val dx = b.x - t.x
                val dy = b.y - t.y
                val dist = sqrt(dx * dx + dy * dy)
                val minDist = b.r + t.r
                if (dist < minDist && dist > 0.1f) {
                    // push out
                    val nx = dx / dist
                    val ny = dy / dist
                    b.x = t.x + nx * minDist
                    b.y = t.y + ny * minDist

                    // reflect velocity
                    val dot = b.vx * nx + b.vy * ny
                    b.vx -= 2f * dot * nx
                    b.vy -= 2f * dot * ny

                    // boost
                    val boost = if (t.isBumper) 280f else 220f
                    b.vx += nx * boost * 0.3f
                    b.vy += ny * boost * 0.7f - 80f

                    score += t.points
                    t.cooldown = if (t.isBumper) 0.25f else 0.4f
                    spawnParticles(t.x, t.y, if (t.isBumper) Color.rgb(255, 180, 40) else Color.rgb(255, 80, 50), 10)

                    if (score >= 1200 && score % 1200 < t.points && balls.size < 3) {
                        addMultiball(w, h)
                    }
                }
            }

            // Flipper collision (line-segment style)
            collideFlipper(b, leftFlipper)
            collideFlipper(b, rightFlipper)

            // Drain
            if (b.y > h + 40f) {
                iterator.remove()
                lives--
                spawnParticles(b.x, h * 0.95f, Color.rgb(180, 180, 160), 6)
            }
        }

        if (balls.isEmpty() && lives > 0) {
            balls.add(Ball(w / 2f, h * 0.55f, Random.nextFloat() * 200f - 100f, -580f))
        }

        if (lives <= 0) {
            playing = false
            saveHighscore(score)
        }
    }

    private fun wallBounce(b: Ball, wallX: Float, isLeft: Boolean, restitution: Float) {
        if (isLeft && b.x < wallX) {
            b.x = wallX
            b.vx = abs(b.vx) * restitution
        } else if (!isLeft && b.x > wallX) {
            b.x = wallX
            b.vx = -abs(b.vx) * restitution
        }
    }

    private fun collideFlipper(b: Ball, f: Flipper) {
        val angleRad = Math.toRadians((if (f.active) f.angle * 0.35f else f.angle).toDouble()).toFloat()
        val cosA = cos(angleRad)
        val sinA = sin(angleRad)

        // Flipper as thick line from pivot to tip
        val tipX = f.cx + cosA * f.length
        val tipY = f.cy + sinA * f.length

        // Closest point on segment to ball
        val dx = tipX - f.cx
        val dy = tipY - f.cy
        val len2 = dx * dx + dy * dy
        var t = if (len2 > 0) ((b.x - f.cx) * dx + (b.y - f.cy) * dy) / len2 else 0f
        t = t.coerceIn(0f, 1f)
        val closestX = f.cx + t * dx
        val closestY = f.cy + t * dy

        val distX = b.x - closestX
        val distY = b.y - closestY
        val dist = sqrt(distX * distX + distY * distY)
        val flipperHalf = 12f

        if (dist < b.r + flipperHalf && dist > 0.01f) {
            val nx = distX / dist
            val ny = distY / dist
            b.x = closestX + nx * (b.r + flipperHalf)
            b.y = closestY + ny * (b.r + flipperHalf)

            val dot = b.vx * nx + b.vy * ny
            b.vx -= 1.6f * dot * nx
            b.vy -= 1.6f * dot * ny

            if (f.active) {
                // strong upward kick
                b.vy = -abs(b.vy) - 380f - Random.nextFloat() * 80f
                b.vx += if (f === leftFlipper) -120f else 120f
                score += 20
                spawnParticles(closestX, closestY, Color.rgb(255, 200, 80), 7)
            } else {
                b.vy *= 0.7f
            }
        }
    }

    private fun addMultiball(w: Float, h: Float) {
        repeat(2) {
            balls.add(Ball(w / 2f + Random.nextFloat() * 40f - 20f,
                h * 0.42f, Random.nextFloat() * 400f - 200f, -650f))
        }
        score += 400
        spawnParticles(w / 2f, h * 0.42f, Color.rgb(100, 255, 150), 18)
    }

    // ─── Particles ─────────────────────────────────────────────

    private fun spawnParticles(x: Float, y: Float, color: Int, count: Int) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2f
            val speed = 80f + Random.nextFloat() * 220f
            particles.add(
                Particle(
                    x, y,
                    cos(angle) * speed,
                    sin(angle) * speed - 60f,
                    0.35f + Random.nextFloat() * 0.4f,
                    0.5f + Random.nextFloat() * 0.3f,
                    color,
                    3f + Random.nextFloat() * 4f
                )
            )
        }
        // limit total particles
        while (particles.size > 80) particles.removeAt(0)
    }

    private fun updateParticles(dt: Float) {
        val it = particles.iterator()
        while (it.hasNext()) {
            val pt = it.next()
            pt.x += pt.vx * dt
            pt.y += pt.vy * dt
            pt.vy += 300f * dt
            pt.life -= dt
            if (pt.life <= 0) it.remove()
        }
    }

    // ─── Highscores ────────────────────────────────────────────

    private fun loadHighscores(): MutableList<Int> {
        val json = prefs.getString("highscores", "[]") ?: "[]"
        val list = mutableListOf<Int>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) list.add(arr.getInt(i))
        } catch (_: Exception) {}
        return list
    }

    private fun saveHighscore(s: Int) {
        if (s <= 0) return
        highscores.add(s)
        highscores.sortDescending()
        while (highscores.size > 5) highscores.removeAt(highscores.lastIndex)
        val arr = JSONArray()
        highscores.forEach { arr.put(it) }
        prefs.edit().putString("highscores", arr.toString()).apply()
    }

    // ─── Input ─────────────────────────────────────────────────

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        val w = width.toFloat()
        val h = height.toFloat()

        if (showHighscores) {
            if (e.action == MotionEvent.ACTION_UP && y > h * 0.78f && y < h * 0.88f) {
                showHighscores = false
                invalidate()
            }
            return true
        }

        if (!playing) {
            if (e.action == MotionEvent.ACTION_UP) {
                if (y > h * 0.42f && y < h * 0.52f) startGame()
                else if (y > h * 0.55f && y < h * 0.64f) {
                    showHighscores = true
                    invalidate()
                }
            }
            return true
        }

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                left = x < w / 2f
                right = !left
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                left = false
                right = false
            }
        }
        return true
    }

    private fun startGame() {
        score = 0
        lives = 3
        balls.clear()
        particles.clear()
        targets.forEach { it.cooldown = 0f }
        if (::leftFlipper.isInitialized) {
            balls.add(Ball(width / 2f, height * 0.55f, Random.nextFloat() * 180f - 90f, -560f))
        }
        playing = true
        last = System.nanoTime()
        invalidate()
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        p.textAlign = Paint.Align.CENTER
        c.drawText(s, x, y, p)
    }
}
