# Keep everything for this simple game
-keep class de.franzfichte.zauberwaldpinball.** { *; }
